<?php
namespace App\service;
interface GenerateNumeroService{
    public function generateNumero():string;
}